export declare const ColorPickerIcon: () => import("react/jsx-runtime").JSX.Element;
