"use strict";
const index = require("../_chunks/index-2b655cca.js");
require("@strapi/helper-plugin");
require("react/jsx-runtime");
require("@strapi/design-system");
require("@strapi/icons");
require("styled-components");
module.exports = index.index;
//# sourceMappingURL=index.js.map
