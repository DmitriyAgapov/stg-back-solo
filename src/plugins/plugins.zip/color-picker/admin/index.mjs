import { i } from "../_chunks/index-10d18ad6.mjs";
import "@strapi/helper-plugin";
import "react/jsx-runtime";
import "@strapi/design-system";
import "@strapi/icons";
import "styled-components";
export {
  i as default
};
//# sourceMappingURL=index.mjs.map
