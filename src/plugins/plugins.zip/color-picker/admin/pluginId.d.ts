export declare const pluginId = "color-picker";
