export declare const getTrad: (id: string) => string;
