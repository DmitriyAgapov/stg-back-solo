declare const _default: {
    register: ({ strapi }: any) => void;
};
export default _default;
//# sourceMappingURL=index.d.ts.map