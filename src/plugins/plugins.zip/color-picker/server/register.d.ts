export declare const register: ({ strapi }: any) => void;
//# sourceMappingURL=register.d.ts.map