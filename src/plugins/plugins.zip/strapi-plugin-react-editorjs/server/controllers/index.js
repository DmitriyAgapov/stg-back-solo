'use strict';

const editorjs = require('./editorjs');

module.exports = {
  editorjs
};
